from flask import Flask, request, jsonify
# from chatbot import get_response  # Assumindo que você tem uma função get_response no seu código Python que retorna a resposta do chatbot
from rag import mainRAG

app = Flask(__name__)

@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    question = data['message']
    
    return jsonify({'response': mainRAG(question)})


if __name__ == '__main__':
    app.run(debug=True)
