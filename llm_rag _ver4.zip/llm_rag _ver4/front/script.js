document.getElementById("sendButton").addEventListener("click", sendMessage);
document.getElementById("userInput").addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        sendMessage();
    }
});

function sendMessage() {
    var userInput = document.getElementById("userInput").value;
    if (userInput.trim() === "") {
        return;
    }

    appendMessage(userInput, "user-message");
    document.getElementById("userInput").value = "";

    fetch('http://localhost:5000/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: userInput }),
    })
    .then(response => response.json())
    .then(data => {
        appendMessage(data.response, "bot-message");
    })
    .catch((error) => {
        console.log('Erro detalhado:', error); // Isso exibirá o erro detalhado no console.
        appendMessage("Desculpe, ocorreu um erro.", "bot-message"); // Isso exibirá uma mensagem genérica para o usuário.
    });
}

function appendMessage(message, className) {
    var chatbox = document.getElementById("chatbox");
    var messageElement = document.createElement("div");
    messageElement.className = "message " + className;
    messageElement.textContent = message;
    chatbox.appendChild(messageElement);
    chatbox.scrollTop = chatbox.scrollHeight;
}
